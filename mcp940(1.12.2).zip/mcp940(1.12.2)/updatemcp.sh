#!/bin/bash
./runtime/updatemcp.py "$@"
