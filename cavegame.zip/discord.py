#!/usr/bin/env python3
from pypresence import Presence
import time

client_id = '583681179291615245'  
RPC = Presence(client_id)  
RPC.connect()

print('Please do not go into this window this is for discordrichprecense open the other one with the title screen of the game')

f = open("levels.txt","r")

b = f.readline()

f.close

Date = time.time()

RPC.update(state="Playing solo", details="Level: "+ b ,large_image="cavegame1024x1024",small_image="pickaxe1024x1024",large_text="Cave Game",small_text="Pickaxe",start=Date)  # Set the presence

while True:  
 time.sleep(1)
 f = open("levels.txt","r")
 b = f.readline()
 f.close
 RPC.update(state="Playing solo", details="Mined: "+ b+" Blocks" ,large_image="cavegame1024x1024",small_image="pickaxe1024x1024",large_text="Cave Game",small_text="Pickaxe",start=Date)  # Set the presence
