import time
import curses
from getkey import getkey, keys
import os
print('Suggested terminal size is: 80 x 23')
print('Move by sd mine with e')
print('for more information about key binds are in')
print('https://meetping.github.io/cavegame/info')
print('to open link press ctrl and click the link with your cursor')

playerx = 1
one = 1
level = 1

def countlvl():
 f = open("levels.txt","w+")
 b = f.readline()
 f.write(str(level))

while True:
 window = curses.initscr()
 window.clear()
 window.addch(22, playerx, '@')
 key = getkey()
 if key == 'd':
   playerx = playerx + one
 elif key == 'a':
   playerx = playerx - one
 elif key == 'e':
   level = level + 1
   countlvl()
 if playerx == 79:
   playerx = 78
 if playerx == 0:
   playerx = 1
 curses.endwin()

